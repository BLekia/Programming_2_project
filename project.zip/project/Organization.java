package project;

public class Organization {
    String name;

    public void print() {
        System.out.println(name);
    }
}